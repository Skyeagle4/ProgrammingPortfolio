Object oriented design.
