#Jake Soulier 1

count = 99
while (count > 1):
   print  count, "bottles of beer on the wall,", count, "bottles of beer."
   print "take one down and pass it around,", count-1, "bottles of beer on the wall."
   print " "
   count = count - 1
print "1 bottle of beer on the wall, 1 bottle of beer."
print "take one down pass it around, no more bottles of beer on the wall."
