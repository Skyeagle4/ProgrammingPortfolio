#include <iostream>
using namespace std;
 
int main () {
   // Local variable declaration:
   int a = 99;

   // while loop execution
   while( a >= 2 ) {
      cout << a << " bottles of beer on the wall " << a << " bottles of beer take one down pass it around" << endl;
      a--;
   }
   while(a = 1){
       cout << a << " bottle of beer on the wall " << a << " bottle of beer take one down pass it around" << endl;
   }
   }
 
   return 0;
}
