int main(){
     int a =99;
     while(a > 2){
     cout << a << �bottles of milk on the wall� << a << �bottles of milk� << �you take one down you pass it around� << a-1 << �bottles of milk on the wall� << endl; 
     a--; 
     }
     while(a < 1){
     cout << a << �bottles of milk on the wall� << a << �bottles of milk� << �you take one down you pass it around� << a-1 << �bottle of milk on the wall� << endl; 
     a--; 
     }

}
