#Andrew Brown   1/25

count = 99
while (count >1 ):
    print count, "Bottles of beer on the wall,", count, "Bottles of beer, take one down pass it around,",count-1,"Bottles of beer on the wall"
    count = count-1
print "1 Bottle of beer on the wall, 1 Bottle of beer, take one down pass it around, 0 Bottles of beer on the wall"
print "0 Bottles of beer on the wall, 0 Bottles of beer, go to the store buy some more, 99 Bottles of beer on the wall"
