//Brooks Boyack, A3, 1-25-2017
#include <iostream>
#include <string>
using namespace std;
 
int main(){
    int b=99;
    b= b --;
    if(b>2){
    cout << b <<"bottles of beverage on the wall"<< b << "bottles of beverage. Take one down pass it around"<<b<<“bottles of beverage on the wall"<<
}else if(b=2){
	cout << b <<"bottles of beverage on the wall"<< b << "bottles of beverage. Take one down pass it around"<<b<<“bottle of beverage on the wall"<<
}else if(b=1) 
	cout << b <<"bottle of beverage on the wall"<< b << "bottles of beverage Take one down pass it around no more bottles of beverage on the wall"<< endl

   
    
 
   
   return 0;
}
