import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceshipClass extends PApplet {

Stars[] stars = new Stars[300];
Spaceship s1;
Laser l1;
Aliens[] aliens = new Aliens[30];
float ssX, lsX, lsY;
int counter, sec;
boolean startGame,hit;

public void setup() {
  noCursor();
  counter = 0;
  startGame = false;
  
  background(0);
  for (int i=0;i<stars.length;i++) {
    stars[i]=new Stars(random(width),random(height));
  }
  l1 = new Laser();
  s1 = new Spaceship();
  for (int i=0;i<15;i++) { // lvl 2 aliens
    aliens[i] = new Aliens((20+80*(i%5)),(40+floor(i/5)*40)-400,2);
  }
  for (int i=15;i<30;i++) { //lvl 1 aliens
    aliens[i] = new Aliens((20+80*((i-15)%5)),(40+floor((i-15)/5)*40),1);
  }
}

public void draw() {
  background(0);
  sec = millis()-1000*floor(millis()/1000);
  for (int i=0;i<stars.length;i++) {
    stars[i].display();
    stars[i].travel();
  }
  for (int i=0;i<aliens.length;i++) {
    aliens[i].display();
    aliens[i].travel();
    aliens[i].collision();
    aliens[i].gameover();
  }
  s1.steer();
  l1.display();
  l1.shoot();
  s1.display();
}
class Aliens {
  //member variables
  float aX, aY, groupX, groupY;
  int dir, lvl;
  boolean dead, wait;

  Aliens(float aX, float aY, int lvl) { //float aW, float aH
    this.aX = aX;
    this.aY = aY;
    this.lvl = lvl;
    dead = false;
    groupX = 10;
    dir = 1;
    wait = false;
  }

  public void display() {
    if (dead == false && lvl == 1) {
      fill(0, 246, 105);
      rect(aX, aY, 30, 10);
      rect(aX-7, aY+5, 10, 10);
      rect(aX+27, aY+5, 10, 10);
      rect(aX+10, aY+5, 10, 10);
    }
    if (dead == false && lvl == 2) {
      fill(245, 236, 27);
      rect(aX, aY, 30, 10);
      rect(aX-7, aY+5, 10, 10);
      rect(aX+27, aY+5, 10, 10);
      rect(aX+10, aY+5, 10, 10);
    }
  }

  public void travel() {
    if (startGame == true && dead == false) {
      if (lvl == 1) {
        if (sec>500 && sec<517) {
          aX+=37*dir;
          groupX+=37*dir;
          wait = true;
        } else if (groupX>=121 || groupX<=10) {  //if the millis>800 for a given second
          if (wait == true && sec>800) {
            aY+=50;
            dir*=-1;
            wait = false; //keeps the ships from shooting down off the screen
          }
        }
      }
      if (lvl == 2 && counter>=15) {
        if (sec>400 && sec<417 || sec>900 && sec<917) {
          aX+=37*dir;
          groupX+=37*dir;
          wait = true;
        } else if (groupX>=121 || groupX<=10) {  //if the millis>800 for a given second
          if (wait == true && sec>800) {
            aY+=50;
            dir*=-1;
            wait = false; //keeps the ships from shooting down off the screen
          }
        }
      }
    }
  }

  public void collision() {
    if (aX-7<lsX && aX+37>lsX && aY<lsY && aY+15>lsY) {
      dead = true;
      hit = true;
      counter+=1;
      aY-=2000;
      aX+=1000;
      println(counter);
    }
    if (counter == 15 && aY<0) {
      lvl = 2;
      aY+=400;
    }
    println(counter);
  }
  
  public void gameover() {
    if (aY>=470) {
      startGame = false;
      fill(255);
      text("GAME OVER",width/2-110,height/2);
    }
    if (counter>=30) {
      startGame = false;
      fill(255);
      text("YOU WIN!",width/2-95,height/2);
    }
  }
}
class Laser {
  //member variables
  float lsXFixed;
  boolean show,powerup;
  
  Laser() {
  }
  
  public void display() {
    fill(255,41,0);
    if (show) {
      lsX = lsXFixed;
      if (lsY>0) {
        lsY-=15;
        rect(lsX,lsY,4,12,3);
      }
      
      //collision detection
      if (lsY<0 || hit == true) {
        show = false;
        hit = false;
      }
    }
  }
  
  public void shoot() {
    if (startGame) {
      if (mousePressed && show == false) {
        lsXFixed = ssX+48;
        lsY = 479;
        show = true;
       }
    }
  }
}
class Spaceship {
  
  //constructor
  Spaceship() {
  }
  
  public void display() {
    fill(220,0,240);
    triangle(ssX+35,495,ssX+45,490,ssX+45,465);
    triangle(ssX+65,495,ssX+55,490,ssX+55,465);
    triangle(ssX+58,485,ssX+42,485,ssX+50,460);
    
    if (millis()>0 && millis()<6000) {
      fill(255);
      textSize(40);
      if (millis()>2000 && millis()<=3000) {
        text("3",width/2-10,height/2);
      } else if (millis()>3000 && millis()<=4000) {
        text("2",width/2-10,height/2);
      } else if (millis()>4000 && millis()<=5000) {
        text("1",width/2-10,height/2);
      } else if (millis()>5000) {
        startGame = true;
      }
    }
  }
  
  public void steer() {
    ssX = mouseX-50;
  }
}
class Stars {
  //member variables
  float starX,starY,starSize,starSpeed,starColor;
  
  //constructor
  Stars(float starX, float starY) {
    this.starX=starX;
    this.starY=starY;
    starSize = random(1,5);
    starSpeed = random(1,3);
    starColor = random(1,10);
  }
  
  public void display() {
    noStroke();
    if (starColor<2.5f) {
      fill(250,250,200); //white stars
    } else if (starColor>2.5f && starColor<8.8f) {
      fill(220,220,150); //yellow stars
    } else if (starColor>8.8f && starColor<9.75f) {
      fill(220,150,150); //red stars
    } else {
      fill(150,150,220); //blue stars
    }
    ellipse(starX,starY,starSize,starSize);
  }
  
  public void travel() {
    starY+=starSpeed;
    if(starY>height) {
      starY=0;
    }
  }
}
  public void settings() {  size(500,500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#000000", "--stop-color=#FFFFFF", "SpaceshipClass" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
