import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class pongame extends PApplet {

Pong p1;
Ball b1;
int x, y, w, h;
boolean hit;
int point;
public void setup() {
  noCursor();
  
  p1 = new Pong(6);
  b1 = new Ball(20, 20, 30, 30, 5, 4);
  x = 50;
  y = height-60;
  w = 80;
  h=20;
  frameRate(120);
  hit = true;
};

public void draw() {
  background(0);
  p1.display();
  p1.keyPressed();
  p1.hit();
  //s1.mouseMovement();
  b1.display();
  b1.collision();
  b1.hitPong();
}
class Ball {
  int x1, y1, w1, h1, s, s2;
  Ball(int x1, int y1, int w1, int h1, int s, int s2) {
    this.x1=x1;
    this.y1=y1;
    this.w1=w1;
    this.h1=h1;
    this.s=s;
    this.s2 = s2;
  }
  public void display() {
    fill(255);
    ellipse(x1, y1, w1, h1);
  }
  public void collision() {
    y1=y1+s;
    
    if (y1>800) {
      y1 = 9000;
      textSize(50);
      background(0);
      
      text("Game Over", width/2-100, height/2);
      text(point-1,height/2+60,550);
      text("Score:",height/2-100,550);
      
    }
    if (y1<0) {
      s=s*-1;
    }

    x1=x1+s2;

    if (x1<0) {
      s2=s2*-1;
    }
    if (x1>700) {
      s2=s2*-1;
    }
  }
  public void hitPong() {
    if (x1 > x &&x1< x+w && y1 >y - 20 && hit == true ) { 
      s = s*-1;
      hit = false;
      point++;
    }
    if (x1 < width/2 && y1 < width/2) {
      hit = true;
    }
    if(point ==6){
     s2=12; 
    }
  }
}

class Pong {
  String name;

  int speed;
  //consturctior blueprint 
  Pong(int speed) {

    this.speed =speed;
  }

  public void display() {
    fill(255);
    textSize(20);
    text("Score:" ,600, 20);
    text(point,670,20);
    fill(228, 250, 91);
    rect(x, y, w, h);
    //left wing
    /*fill(255,0,0);
     rect(225,260,25,50);
     //right wing
     rect(300,260,25,50);
     fill(88,234,233);
     //body blue
     triangle(250,250,250,300,300,300);
     //head
     //noStroke();
     rect(265,220,20,30);
     */
  }

  public void keyPressed() {
    if (keyCode == LEFT ) {
      x=x-speed;
    } else if (keyCode == RIGHT) {
      x=x+speed;
    }
  }

  public void hit() {
    if (x>740) {
      x=10;
    }
    if (x<0) {
      x=740;
    }
  }
}
  public void settings() {  size(700, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#42EAE9", "--stop-color=#FF0000", "pongame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
