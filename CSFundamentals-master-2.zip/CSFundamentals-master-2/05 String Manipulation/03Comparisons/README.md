Comparing strings.
