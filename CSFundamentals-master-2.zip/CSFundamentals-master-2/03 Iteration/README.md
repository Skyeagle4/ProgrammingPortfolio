Loops for programming
