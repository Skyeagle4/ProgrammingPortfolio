The for loop is the workhorse of most languages.
