#Howard Ying, Period 3A, Completed 01-27-2017
vowels = ["a","e","i","o","u"]
userInput = raw_input("Enter one word in English: ")
userInput = userInput.lower()
firstLetter = userInput[0]
word = userInput[1:]
if firstLetter in vowels:
    result = userInput + "way"
else:
    result = word + firstLetter + "ay"
print "Pig Latin Translation: " + result
