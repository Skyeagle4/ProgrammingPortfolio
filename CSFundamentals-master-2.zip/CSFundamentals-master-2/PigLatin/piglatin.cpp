#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[])
{
   string str1, str2, str3;
   str3 = "ay";
   cout << "Pig latin translator";
   cin >> str1;
   str2 = str1,substr(0,1);
   cout << str1.substr(1) << str2 << str3;
   return 0;
}
