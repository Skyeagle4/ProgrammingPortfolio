#Andrew Brown 1/27

print 'Welcome to the Pig Latin Translator!'

pyg = 'ay'
vowels = 'aeiouAEIOU'

original = raw_input('type the word you want to be pyglatin :) :')

if len(original)>0 and original.isalpha():
    word = original.lower()
    first = word[0]
    if first in vowels:
        new_word = word + 'way'
    else:
        new_word = "%s%s%s" %(word,first,pyg)
        new_word = new_word[1:len(new_word)]
    
    print new_word
       
else: print "empty"
