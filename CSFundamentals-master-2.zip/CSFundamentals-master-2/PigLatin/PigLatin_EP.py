pig = 'ay'

word1 = raw_input('Input a word in English')
first1 = word1[0]

word2 = raw_input('Input another word in English')
first2 = word2[0]

newWord = word1[0:] + first1 + pig+ ' ' + word2[0:] + first2 + pig
print newWord

# By Edward Prutski
