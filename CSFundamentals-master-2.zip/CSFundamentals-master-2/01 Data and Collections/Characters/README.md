Chars are cool
