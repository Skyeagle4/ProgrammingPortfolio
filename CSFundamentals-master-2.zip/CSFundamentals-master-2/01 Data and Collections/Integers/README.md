Integers are cool
