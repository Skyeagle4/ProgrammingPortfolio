Please upload your working directory with 4 files here!
