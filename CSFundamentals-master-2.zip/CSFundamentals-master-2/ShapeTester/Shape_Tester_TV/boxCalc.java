public class boxCalc {
	public double height;
	public double length;
	public double width;
	public boxCalc(double h, double l, double w) {
		height = h;
		length = l;
		width = w;
	}
	public double getSurfaceArea() {
		double surfaceArea = 2 * ((l * w) + (h * l) + (h * w));
		return surfaceArea;
	}
	public double getVolume() {
		double volume = h * l * w;
		return volume;
	}
}
