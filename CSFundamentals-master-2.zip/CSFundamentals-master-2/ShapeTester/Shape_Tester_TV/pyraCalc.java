import java.lang.Math;
public class pyraCalc {
	public double height;
	public double length;
	public double width;
	public pyraCalc(double h, double l, double w) {
		height = h;
		length = l;
		width = w;
	}
	public double getSurfaceArea() {
		double surfaceArea = (l * w) + (l * (Math.sqrt(Math.pow((w / 2), 2) + Math.pow(h, 2))) + w * (Math.sqrt(Math.pow((l / 2), 2) + Math.pow(h, 2)));
		return surfaceArea;
	}
	public double getVolume() {
		double volume = (h * l * w) / 3;
		return volume;
	}
}
