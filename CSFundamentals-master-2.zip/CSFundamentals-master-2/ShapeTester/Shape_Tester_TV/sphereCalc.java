import java.lang.Math;
public class sphereCalc {
	public double radius;
	public sphereCalc(double r) {
		radius = r;
	}
	public double getSurfaceArea() {
		double surfaceArea = 4 * Math.PI * Math.pow(r, 2);
		return surfaceArea;
	}
	public double getVolume() {
		double volume = (4 / 3) * Math.PI * Math.pow(r, 3);
		return volume;
	}
}
