import Box from Box
import Pyramid from Pyramid
import Sphere from Sphere
run = True

while run:
    print("For box surface area and volume, enter [1]. \n For pyramid surface area and volume, enter [2]. \n For sphere surface area and volume, enter [3.]")
    choice = input("Enter Choice: ")
    
    if choice == 1:
        bLength = input("Length of box: ")
        bWidth = input("Width of box: ")
        bHeight = input("Height of box: ")
        b = Box(bLenth, bWidth, bHeight)
        b.calcV()
        b.calcSA()
        print ("Volume of box: ", b.calcV)
        print ("Surface Area of box: ", b.calcSA)
    elif choice == 2:
        pLength = input("Length of pyramid: ")
        pWidth = input("Width of pyramid: ")
        pHeight = input("Height of pyramd: ")
        p = Pyramid(pLength, pWidth, pHeight)
        p.calcV()
        p.calcSA()
        print("Volume of pyramid: ", p.calcV)
        print("Surface area of pyramid: ", p.calcSA)
    elif choice == 3:
        sRadius = input("Radius of pyramid: ")
        s = Sphere(sRadius)
        s.calcV()
        s.calcSA()
        print ("Volume of sphere: ", s,calcV)
        print ("Surface area of sphere: ", s.calcSA)
    else:
        print ("Your shape choice is invalid")