import math
class Sphere:
    def _init_(self, sRadius):
        self.sRadius = int(sRadius)
        
    def calcV(self, sRadius):
        print ("Volume:" + str(((4/3)*math.pi)*sRadius**3))
        
    def CalcSA(self, sRadius):
        print ("Surface Area" + str(4*math.pi*sRadius**2))
        
    
