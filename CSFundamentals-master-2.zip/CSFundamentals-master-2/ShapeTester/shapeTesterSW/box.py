class Box:
    def _init_ (self,bLength, bWidth, bHeight):
        self.bLength = int(bLength)
        self.bWidth = int(bWidth)
        self.bHeight = int(bHeight)
        
    def calcV(self, bLength, bWidth, bHeight):
        print ("Volume:" + str(bLength*bWidth*bHeight))
        
    def calcSA (self, bLength, bWidth, bHeight):
        print ("Surface Area:" + str(2*bLength*bHeight+2*bWidth*bHeight))