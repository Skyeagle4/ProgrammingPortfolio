class Pyramid:
    def _init_(self, pLength, pWidth, pHeight):
        self.pLength = int(pLength)
        self.pWidth = int(pWidth)
        self.pHeight = int(pHeight)
    
    def calcV(self, pLength, pWidth, pHeight):
        print ("Volume:" + str(pLength*pWidth*pHeight)/3)

    def calcSA(self, pLengh, pWidth, pHeight):
        print ("Surface Area:" + str((pLength*pWidth)*(pLength*(((pWidth/2)**2)+pHeight**2)**0.5)+(pWidth*(((pLenght/2)**2)+pHeight**2)**0.5)))