include <iostream>
#include<cmath>
#include<math.h>
using namespace std;

class sphere{
    public:
        double radius; //radius of the sphere
     
        
};
int main(){
    sphere sphere1; //Declare radius1
    double volume = 0.0; //Store the volume of the sphere
    sphere1.radius;
     
    //User input of sphere dimensions
    cout << "Enter radius of the pyramid" << endl;
    cin >> sphere1.radius; 
    
    //Volume of sphere
    volume = 4/3 * (M_PI * sphere1.radius * sphere1.radius * sphere1.radius);
    cout << volume << endl;
    
    //Surface area of sphere
    surfaceArea = 4 * (M_PI *sphere1.radius * sphere1.radius);
    cout << surfaceArea << endl;
    