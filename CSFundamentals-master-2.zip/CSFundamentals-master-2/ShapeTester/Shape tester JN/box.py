class Box:
   'welcome to shape maker! lets find volume and surface area for a few shapes'
   boxCount = 0

def __init__(self, l, h, w):
   self.l = l
   self.h = h
   self.w = w
   
def calcVol(self, l, h, w):
   print ("The volume for your box:" + str(l, h, w))

def calcSur(self):
   print ("The surface area is: " + str(2*(l, h, w)))
    