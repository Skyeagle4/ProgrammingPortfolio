public class TinyBoxTim{
 private   double length;
    private double width;
    private double height;
public TinyBoxTim(double w, double l, double h){
    
        }
    public double getSurfaceArea() {
        double surfaceArea = 2 * (length * height + width * height);
        return surfaceArea;
    }
    public double getVolume() {
        double volume = length * width * height;
        return volume;
    }

}
