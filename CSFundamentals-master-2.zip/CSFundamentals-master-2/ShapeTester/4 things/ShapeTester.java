//personality shape maker
import java.util.Scanner;

public class ShapeTester {
    public static void main(String[] args) {
        int boxW, boxL, boxH;
        Scanner scan = new Scanner(System.in);
        System.out.println("Alright nerd, let's make some shapes. Lets find the volume and surface area for a few shapes...");
        System.out.println("How about we start with... a box. Sounds like a nice shape to start with! Enter the width of the box here: ");
        boxW = scan.nextInt();
        System.out.println("Enter the length of your box: ");
        boxL = scan.nextInt();
        System.out.println("Enter the height of the box: ");
        boxH = scan.nextInt();
        Box box = new Box(boxW, boxL, boxH);
        System.out.println("Surface Area of Box: " + box.getSurfaceArea());
        System.out.println("Great job! Here's the volume of your box: " + box.getVolume());
        
          int pyramidH, pyramidB;
        System.out.println("Now a square base pyramid, because the ancient peoples knew best. Enter height of the pyramid: ");
       //personality shape maker
import java.util.Scanner;

public class ShapeTester {
    public static void main(String[] args) {
        int boxW, boxL, boxH;
        Scanner scan = new Scanner(System.in);
        System.out.println("Alright nerd, let's make some shapes. Lets find the volume and surface area for a few shapes...");
        System.out.println("How about we start with... a box. Sounds like a nice shape to start with! Enter the width of the box here: ");
        boxW = scan.nextInt();
        System.out.println("Enter the length of your box: ");
        boxL = scan.nextInt();
        System.out.println("Enter the height of the box: ");
        boxH = scan.nextInt();
        Box box = new Box(boxW, boxL, boxH);
        System.out.println("Surface Area of Box: " + box.getSurfaceArea());
        System.out.println("Great job! Here's the volume of your box: " + box.getVolume());
        
          int pyramidH, pyramidB;
        System.out.println("Now a square base pyramid, because the ancient peoples knew best. Enter height of the pyramid: ");
        pyramidH = scan.nextInt();
        System.out.println("Enter base length of the pyramid: ");
        pyramidB = scan.nextInt();
        Pyramid pyramid = new Pyramid(pyramidH, pyramidB);
        System.out.println("Surface Area of Pyramid: " + pyramid.getSurfaceArea());
        System.out.println("Volume of Pyramid: " + pyramid.getVolume());
        
        int sphereR;
        System.out.println("Now Let's try a sphere, because, you know...planets. Enter the radius of the sphere: ");
        sphereR = scan.nextInt();
        Sphere sphere = new Sphere(sphereR);
        System.out.println("Surface Area of Sphere: " + sphere.getSurfaceArea());
        System.out.println("Volume of Sphere: " + sphere.getVolume());
        
      
    }
} pyramidH = scan.nextInt();
        System.out.println("Enter base length of the pyramid: ");
        pyramidB = scan.nextInt();
        Pyramid pyramid = new Pyramid(pyramidH, pyramidB);
        System.out.println("Surface Area of Pyramid: " + pyramid.getSurfaceArea());
        System.out.println("Volume of Pyramid: " + pyramid.getVolume());
        
        int sphereR;
        System.out.println("Now Let's try a sphere, because, you know...planets. Enter the radius of the sphere: ");
        sphereR = scan.nextInt();
        Sphere sphere = new Sphere(sphereR);
        System.out.println("Surface Area of Sphere: " + sphere.getSurfaceArea());
        System.out.println("Volume of Sphere: " + sphere.getVolume());
        
      
    }
}