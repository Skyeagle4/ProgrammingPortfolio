import math

class Sphere :

    def __init__(self, r) :
            self.r = r

    def getVolume(self) :
        print "\nVolume =", (4/3)*math.pi*(self.r**3)
    
    def getSurfaceArea(self):
        print "Surface area =", 4*math.pi*(self.r**2), "\n"