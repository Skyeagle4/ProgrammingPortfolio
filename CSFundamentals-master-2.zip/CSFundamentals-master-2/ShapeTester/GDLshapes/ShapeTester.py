from Box import Box
b1 = (input(" Enter length: "),input("Enter width: "),input("Enter height: "))
print ("The volume of your box is:"), V

from Pyramid import Pyramid
p1 = (input(" Enter length: "),input("Enter height: "))
print ("The volume of your pyramid is:"), V


from Sphere import Sphere
s1 = (input(" Enter radius: "))
print ("The volume of your sphere is:"), V





 

