#greylarson
class Pyramid:
    def __init__(self,length.width,height):
        self.length = length
        self.width = width
        self.height = height
        self.vol = 0
        self.surfArea = 0
    def getVol(self):
        self.vol = (self.length*self.width*self.h)eight/3
    def getsurfArea(self):
        import math
        width = self.width
        height = self.height
        length = self.length
        self.surfArea = (l*w) + (length*pow((pow((width/2),2)+pow(height,2)),(.5))) + (width*pow((pow((l/2),2)+pow(height,2)),(.5)))
