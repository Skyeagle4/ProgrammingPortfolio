#greylarson
class Sphere:
    
    def __init__(self, width, height, breadth):
        self.radius = r
        self.vol = 0
        self.surfArea = 0
    def getVol(self):
        import math
        self.vol= ((4 * math.pi) / 3) * math.pow(self.r,3)
    def getsurfArea
        import math
        self.surfArea = 4 * math.pi * math.pow(self.r,2)
