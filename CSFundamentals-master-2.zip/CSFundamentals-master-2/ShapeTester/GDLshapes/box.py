#greylarson
class Box:
    
    def __init__(self, width, height, length):
        self.width = width
        self.height = height
        self.breadth = length
        self.vol = 0
        self.surfArea = 0
    def getBoxVol(self):
        self.vol = int(width) * int(height) * int(length) 
    def getBoxSurfArea(self):
        self.surfArea = (2 * int(length) * int(height)) + (2* int(width) * int(height))
        
