#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;



class sphere {
   public: 
      double volume
      double radius;   
      
      
   
};

int main( ) {
    sphere sp;
    double volume;
    double radius = 0;
   
    cout << "what is the radius of the sphere”<< endl;
    cin >> radius;
       
     volume = 4/3 *(M_PI * sp.radius * sp.radius * sp.radius);
   cout << "Volume  : " << volume <<endl;
   
   surfaceArea = 4 * (M_PI * sp.radius * sp.radius);
cout << surfaceArea << endl;

 
 