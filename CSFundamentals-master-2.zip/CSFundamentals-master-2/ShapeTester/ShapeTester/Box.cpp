#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;



class Box {
   public:
      double length;   
      double breadth;  
      double height;
      
   
};

int main( ) {
    double surfaceArea = 0;
    double volume = 0;
    Box Box1;
    Box1.height;
    Box1.breadth;
    Box1.length;
    
    cout << "what is the height of the box"<< endl;
    cin  >>  Box1.height; 
    cout << "what is the breadth of the box" << endl;
    cin  >> Box1.breadth;
    cout << "what is the length of the box" << endl;
    cin >> Box1.length;
    
    volume = Box1.height * Box1.length * Box1.breadth;
   cout << "Volume of Box1 : " << volume <<endl;
   
   surfaceArea = (Box1.height * Box1.length+ Box1.height * Box1.breadth + Box1.breadth * Box1.length ) *2;     
   cout << "Surface Area of Box1: " << surfaceArea << endl;
   return 0;
};
