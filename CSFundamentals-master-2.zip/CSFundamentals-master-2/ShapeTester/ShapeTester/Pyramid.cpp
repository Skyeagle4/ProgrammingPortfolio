#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;



class Pyramid {
   public:
      double length;   
      double breadth;  
      double height;
      
   
};

int main( ) {
    double surfaceArea = 0;
    double volume = 0;
    Pyramid Pyramid1;
    Pyramid1.height;
    Pyramid1.breadth;
    Pyramid1.length;
    
    cout << "what is the height of the Pyramid"<< endl;
    cin  >>  Pyramid1.height; 
    cout << "what is the breadth of the Pyramid" << endl;
    cin  >> Pyramid1.breadth;
    cout << "what is the length of the Pyramid" << endl;
    cin >> Pyramid1.length;
    
    volume = ((Pyramid1.height * Pyramid1.length * Pyramid1.breadth)/3);
   cout << "Volume of Pyramid1 : " << volume <<endl;
   
   

   return 0;
};

 