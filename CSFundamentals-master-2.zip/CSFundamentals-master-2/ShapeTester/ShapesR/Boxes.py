
class Box:
   'Welcome to shape maker!  Lets find volume and surface area for a few shapes...'
   boxCount = 0

   def __init__(self, l, h, w):
      self.l = l
      self.h = h
      self.w = w
   
   def calcVol(self):
      result = self.l*self.h*self.w
      print "The volume for your box:", result

   def displayBox(self):
      print "Length : ", self.l,  "Heigth : ", self.h, "Width :", self.w
      
   def calcSur(self):
      result = (2*self.l*self.h)+(2*self.w*self.h)
      print "The surface area for your box:", result


