#By Edward Prutski
#Period A3 Programming 1
#+Added New Cylinder Class


from Box import Box
from Pyramid import Pyramid
from Sphere import Sphere
from Cylinder import Cylinder

option = input("Which Shape would you like? |1 - box| |2 - pyramid| |3 - sphere| |4 - Cylinder| : ")
option = int(option)

#BOX
if option == 1:
    width = input("enter width: ")
    height = input("enter height: ")
    breadth = input("enter length: ")

    b1 = Box(width,height,breadth)
    b1.calcVolume()
    b1.calcSA()

    print ("Your Volume is: ", b1.vol)
    print ("Your Surface Area is: ", b1.sa)
#PYRAMID
elif option == 2:
    width = input("enter width: ")
    height = input("enter height: ")
    length = input("enter length: ")

    p1 = Pyramid(width,height,length)
    p1.calcVolume()
    p1.calcSA()

    print ("Your Volume is: ", p1.vol)
    print ("Your Surface Area is: ", p1.sa)

#SPHERE
elif option == 3:

    radius = input("Enter the radius: ")

    s1 = Sphere(radius)
    s1.calcVolume()
    s1.calcSA()

    print ("Your Volume is: ", s1.vol)
    print ("Your Surface area is: ",s1.sa)

elif option == 4:

    radius = input("Enter the radius: ")
    height = input("Enter the height: ")

    c1 = Cylinder(radius,height)
    c1.calcVolume()
    c1.calcSA()

    print ("Your Volume is: ", c1.vol)
    print ("Your Surface area is: ", c1.sa)

else:

    print ("Invalid Input")


