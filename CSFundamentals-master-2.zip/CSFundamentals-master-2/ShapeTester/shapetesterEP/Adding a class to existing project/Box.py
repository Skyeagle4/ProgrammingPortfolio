class Box :
    
    def __init__(self,width, height, breadth):
        self.width = int(width)
        self.height = int(height)
        self.breadth = int(breadth)
        self.vol = 0
        self.sa = 0
        
    def calcVolume(self):
        self.vol = (self.width)*(self.height)*(self.breadth)
        
    def calcSA(self):

        self.sa = ((self.breadth*self.height)*2)+((self.width*self.height)*2)+((self.breadth*self.width)*2)
        
