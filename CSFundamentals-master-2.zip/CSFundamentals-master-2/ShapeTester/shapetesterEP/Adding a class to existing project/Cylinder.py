class Cylinder :

    def __init__(self,radius,height):
        self.radius = int(radius)
        self.height = int(height)

    def calcVolume(self):
        import math
        self.vol = (3.14)*(math.pow(self.radius,2))*(self.height)

    def calcSA(self):
        import math
        self.sa = (2*3.14*self.radius*self.height)+(2*3.14*math.pow(self.radius,2))
