class Sphere :
    
    def __init__(self,radius):
        self.radius = int(radius)

    def calcVolume(self):
        import math
        self.vol = (4/3)*(3.14)*(math.pow(self.radius,3))

    def calcSA(self):
        import math
        self.sa = (4)*(3.14)*(math.pow(self.radius,2))
