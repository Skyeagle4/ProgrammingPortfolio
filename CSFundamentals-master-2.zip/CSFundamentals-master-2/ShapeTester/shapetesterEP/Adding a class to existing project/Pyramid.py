class Pyramid :
    import math
    def __init__(self,length,width,height):
        self.length = int(length)
        self.height = int(height)
        self.width = int(width)
        self.vol = 0
        self.sa = 0

    def calcSA(self):
        self.sa = (self.length*self.width)+(self.length*pow((pow((self.width/2),2)+pow(self.height,2)),(.5)))+(self.width*pow((pow((1/2),2)+pow(self.height,2)),(.5)))

    def calcVolume(self):
        self.vol = (self.length*self.width*self.height)/3
