Using data collections in programming.
