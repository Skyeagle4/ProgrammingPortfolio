Return functions
