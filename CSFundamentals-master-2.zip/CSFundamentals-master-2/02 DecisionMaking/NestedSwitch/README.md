Nested Switch
