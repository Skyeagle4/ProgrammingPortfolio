CS Fundamentals
==============

Basic concepts related to computer science and programming in C++, Java, C#, and Python.

Resources
==============

## Websites
Sites used within the curriculum and well worth your time...

### Educational Resources
Runstone Interactive:
    <a href="http://interactivepython.org/runestone/default/user/login?_next=/runestone/admin/index">Excellent Online Interactive Texts</a>

Khan Academy:
    <a href="http://www.khanacademy.org/cs">Computer Science</a>

Code.org:
    <a href="http://www.code.org">CS Lessons</a>
   
Intro Text:
    <a href="http://chortle.ccsu.edu/java5/index.html#03">Computer Science using Java</a>
    
Online Editor:
    <a href="http://www.compileonline.com">CompileOnline.com</a>
    
### Language Standards
Processing:
    <a href="http://processing.org/reference/">Official Processing Site</a>

Learning Processing:
    <a href="http://learningprocessing.com">DANIEL SHIFFMAN's Learning Companion Site</a>

C++:
    <a href="http://www.cplusplus.com/reference/">cplusplus.com</a> | 
    <a href="https://github.com/cplusplus">GitHub Docs</a>

Java:
    <a href="http://docs.oracle.com/javase/7/docs/api/">Official Sun Java Docs</a>
    
Python:
    <a href="http://www.python.org/doc/">Official Python.org</a>

C#:
    <a href="http://msdn.microsoft.com/en-us/library/67ef8sbd.aspx">Microsoft C# Docs</a>

### Data Sets
Princeton.edu:
    <a href="http://introcs.cs.princeton.edu/java/data/">Real-World Data Sets</a>

Stanford.edu:
    <a href="http://snap.stanford.edu/data/">Large Data Sets</a>
    
KDNuggets:
    <a href="http://www.kdnuggets.com/datasets/index.html">Massive Link List</a>

### Just for FUN

Programming Challenges: 
    <a href="http://programmers.stackexchange.com/questions/756/where-can-i-find-programming-puzzles-and-challenges">Stack Overflow</a>
