# [Information Age](http://en.wikipedia.org/wiki/Information_age)

What is [data](http://en.wikipedia.org/wiki/Data_(computing))? How do we measure data? How is data stored? How do we move information? These are all questions at the heart of the information age.

### History of the [Bit](http://en.wikipedia.org/wiki/Bit)

#### Examples of how the bit is interpreted:
- 0 or 1
- On or Off
- Yes or No
- True or False
- Black or White
- Flip or Flop

### From Bits to Bytes and Beyond

### Megabit vs. MegaByte: Is there a difference?

### References and Resources
