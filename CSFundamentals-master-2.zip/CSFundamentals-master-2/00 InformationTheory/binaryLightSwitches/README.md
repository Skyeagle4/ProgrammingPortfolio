# Binary Light Switches
This is a project that was imagined 10 years ago and came to fruition in January 2013 thanks to the Processing programming language. The idea is simple, represent each bit as a switch in an effort to demonstrate how to count in a 2 bit system.

### To the Next Level
After perfecting the switch idea, visualizing RGB color was the next goal. That project can be view at [24 Bit RGB Color Explained](http://dl.dropboxusercontent.com/u/21278437/heart/colorVis/index.html).
