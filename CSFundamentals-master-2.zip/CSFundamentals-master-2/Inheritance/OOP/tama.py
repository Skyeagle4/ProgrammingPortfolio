from big import big
class Tama:
    def tan(self, character):
        self.character = c
    
    def Animal(self):
        tester = input("What character do you use? \n1. Memetchi \n2. Kuckipatchi \n3. Chamametchi\n4. Tenpatchi\n")
        
        if tester == 1:
            print "Memetchi"
            
        if tester == 2:
            print "Keckipatchi"
            
        if tester == 3:
            print "Chamaetchi"
            
    def Color(self):
        input("What color is your tamagotchi?")