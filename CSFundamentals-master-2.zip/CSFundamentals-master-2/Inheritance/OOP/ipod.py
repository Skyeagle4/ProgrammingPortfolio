#from vehicals import device
from big import big
class ipod:
    def __int__(self,music):
        self.music = m
    
    def Display(self):
        print input("How many songs can your ipod hold? ") /200, "gb"
        
    