#from vehicals import device
from big import big

class Phone:
    def can(self, service):
        self.service = s
    
    def Cellular(self):
        testor = input("What cellular service do you use? \n1. Sprint \n2. Verizon \n3. AT&T \n4. T Mobile\n")
        
        if testor == 1:
            print "Sprint"
            
        if testor == 2:
            print "Verizon"
            
        if testor == 3:
            print "AT&T"
            
        if testor == 4:
            print "T Mobile"
        
r = big()
r.Memory()