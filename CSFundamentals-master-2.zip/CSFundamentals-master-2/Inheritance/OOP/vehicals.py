from phone import Phone
from ipod import ipod
from walkie import walkietalkie
from tama import Tama
from big import big

device = input("Choose your device: \n1. Phone \n2. Ipod \n3. Walkie \n4. Tamagotchi \n")

if device == 1:
    c = Phone()
    c.Cellular()
    
if device == 2:
    b = ipod()
    b.Display()
    
if device == 3:
    a = walkietalkie()
    a.Display()
    
if device == 4:
    d = Tama()
    d.Animal()
    d.Color()


#e = big()      
#e.Weight()

#c=Phone()
#c.Cellular()
#b=ipod()
#b.Display()
#b.Weight()
#a=walkie()
#a.Display()