from big import big   
class walkietalkie:
    def __int__(self, distance):
        self.distance = d
    
    def Display(self):
        print input("How far can your walkietalkie reach?"), gb