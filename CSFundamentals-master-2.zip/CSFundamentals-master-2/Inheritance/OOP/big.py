
class big:   
    def __int__(self,weigth, batteryhrs, memory, make):
        self.weight = w
        self.batteryhrs = b
        self.memory = m
        self.make = ma
        
    def Weigth(self):
        result = self.w
        print 'Prints weight (oz.): ', result
        
    def batteryhours(self):
        print 'Prints battery hours: '
        
    def Memory(self):
        print 'Prints total memory: '  
    def Make(self):
        print 'Prints make type: '