#include<iostream>
using namespace std;

class characters{
public:

void setSpeed(int s){
    speed = 10;
}
void setLives(int l){
    lives = 3;
}
void setHealth(int h){
    health = 100;
}
void setKills(int k){
    kills = 0;
}
void setLevel(int l){
    level =0;
}
void setAltcharge(int a){
    altCharge = 0;
}

private:
int speed;
int lives;
double health;
int kills;
int level;
int altCharge;

};

class Brain: public characters{
    public:
        
        void if (headshot < limit){
            h = true;
            return(kills * 1.5)
        }else(){
            h = false;
        }
        
        void killLimit(kills >limit){
            headshot = false;
        }
    private:
    bool h;
    void headshot;
    h = false;
    int limit = 10;
    headshot = h;
};

class Steven: public characters{
    public:
        void setXpos(int x){
            x = xpos
        }
        
        void setYpos(int y){
            y = ypos
        }
        
        void teleport(){
            if(teleport){}
            xpos + random(3-10);
            ypos + random(3-10);
        }
        
        
    private:
        int xpos;
        int ypos;
};

class Joe: public characters{
  public:

    void gethealth(){
        if(heal<100){
            healed = true;
            health = health + heal;
        }
        if(healed = true){
           heal = 0; 
            
        }
    }  
  private:
    int heal = 20;
    bool healed;
    healed = false;
     
};
 cout << "What type of player are you? Headhunter, Teleporter or selfhealer" << endl;
 cin >> player
 
 if (player == Headhunter){
    
    cout << "You Character is Brain he get plus 50% more alt charge for each headshot kill " << endl;
 } if else (player == speedmaster){
    
    cout << "your character is Greg he randomly teleport to a diffrent place this can be helpful to doge attacks" << endl;
 }else{
    
    cout <<"your character is joe he can slef heal up to 20% of his health" << endl;
 }
 
 
