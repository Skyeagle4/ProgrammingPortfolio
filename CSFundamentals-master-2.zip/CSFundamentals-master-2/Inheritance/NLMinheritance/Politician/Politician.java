//Nastassja Motro 02/05/17

package politician;

public interface Politician {
  void saySlogan();
  double changeTaxes(double income, double initialRate);
}