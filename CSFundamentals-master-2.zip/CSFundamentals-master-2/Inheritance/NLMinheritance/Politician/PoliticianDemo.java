//Nastassja Motro 02/05/17
// this is the entry point

package politician;

public class PoliticianDemo {
  public static void main(String[] args) {
    // Politician generic = new Politician();
    
    Trump Donald = new Trump();
    Clinton Hillary = new Clinton();
    Donald.saySlogan();
    Hillary.saySlogan();
  }  
}
