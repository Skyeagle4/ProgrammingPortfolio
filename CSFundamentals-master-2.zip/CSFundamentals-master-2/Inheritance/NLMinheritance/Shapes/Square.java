//Nastassja Motro 02/05/17

package shapes;

public class Square extends Rectangle {
  public Square(double _sideLength) {
    super(_sideLength, _sideLength);
  }
} 