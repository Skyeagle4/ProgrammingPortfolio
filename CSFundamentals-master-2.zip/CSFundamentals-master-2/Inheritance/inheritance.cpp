#include <iostream>

using namespace std;

//Base class
class Aircraft{
    public:
        void setWidth(int w){
         Width = w;
        }
        void setHeight(int h){
        Heigth = h;
        }
        void setLength(int l){
        Length = l;
        }
        void setWeight(int t){
        Weight = t;
        }
        void setEngines(int e){
        Engines = e;
        }
        void setSpeed(int s){
        Speed = s;
        }
        void setFly(int f){
        Fly = f;
        }
        protected:
            int l;
            int w;
            int h;
            int t;
            int e;
            int s;
            int f;
};

//Sub class
class Helicopter: public Aircraft{
    public:
        void setPropellers(int r){
        propellers = r;
        }
        void setPassengers(int p){
        passengers = p;
        }
};

//Sub class
class Quad: public Aircraft{
    public:
        void setPropellers(int r){
        propellers = r;
        }
        void setCamera(int c){
        camera = c;
        }
};

//Sub class
class airPlane: public Aircraft{
        public:
        void setWingspan(int g){
        wingspan = g;
        }
        void setWings(int z){
        passengers = p;
        }
};

cin << weight << endl;
