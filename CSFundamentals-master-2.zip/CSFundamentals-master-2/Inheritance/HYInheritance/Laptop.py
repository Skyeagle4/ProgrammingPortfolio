from Computer import Computer

class Laptop(Computer):
    def __init__(self, keyboard, GPU, battSize):
        Computer.__init__(self, raw_input("What is the manufacturer of the Computer?\n"), raw_input("What is the model name?\n"), input("How many watt hours does the computer consume?\n"))
        self.keyboard = False
        self.opticalDrive = False
        self.battSize = 0
        self.battLife = 0
    
    def setInfo(self):
        Laptop.keyboard = bool(input("Is the keyboard backlit? True/False\n"))
        Laptop.opticalDrive = bool(input("Is there an optical drive? True/False\n"))
        Laptop.battSize = input("What is the size of the battery in watt hours?\n")
    
    def calcbattLife(self):
        self.battLife = Laptop.battSize/1500
        print ("Your computer will last ") + str(self.battLife) + (" hours.")
