from Computer import Computer

class Desktop(Computer):
    def __init__(self, dGPU, cost, storage):
        Computer.__init__(self, raw_input("What is the manufacturer of the Computer?\n"), raw_input("What is the model name?\n"), input("How many watt hours does the computer consume?\n"))
        self.dGPU = False
        self.cost = 0
        self.storage = 0
        self.costPerGB = 0
        
    def setInfo(self):
        Desktop.dGPU = bool(input("Does the computer have a discrete GPU? True/False\n"))
        Desktop.storage = input("In gigabytes, how much storage capacity does the computer have?\n")
        Desktop.cost = input("What is the cost of the computer? \n$")
        
    def calccostPerGB(self):
        self.costPerGB = Desktop.cost/Desktop.storage
        print ("One GB of storage costs: $") + str(self.costPerGB) + (".")
