class Computer:
    def __init__(self, manufacturer, model, powerConsumption):
        self.manufacturer = manufacturer
        self.model = model
        self.powerConsumption = powerConsumption
        self.operateCost = 0
        
    def calcoperateCost(self):
        self.operateCost = ((self.powerConsumption/1000)*0.12)*8760
