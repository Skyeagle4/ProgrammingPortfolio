from Computer import Computer

class Supercomputer(Computer):
    def __init__(self, country, FLOPS, numOfProcessors):
        Computer.__init__(self, raw_input("What is the manufacturer of the Computer?\n"), raw_input("What is the model name?\n"), input("How many watt hours does the computer consume?\n"))
        self.country = country
        self.size = 0
        self.numOfProcessors = 0

    def setInfo(self):
        Supercomputer.country = raw_input("What is the country of origin? \n")
        Supercomputer.size = input("How much space does the supercomputer take up, in cubic feet?\n")
        Supercomputer.numOfProcessors = input("How many processors are in the supercomputer?\n")

    def calcspacePerProcessor(self):
        self.spacePerProcessor = Supercomputer.size/Supercomputer.numOfProcessors
        print("Each processor takes up ") + str(self.spacePerProcessor) + (" cubic feet.")
