#Howard Ying, Period 3A, Completed 03-06-2017

from Computer import Computer
from Laptop import Laptop
from Desktop import Desktop
from Supercomputer import Supercomputer

print("Please select the type of computer.")
choice = input("1. Laptop\n2. Desktop\n3. Supercomputer\n")

if choice == 1:
    c = Laptop(False, False, 0)
    c.setInfo()
    c.calcbattLife()

elif choice == 2:
    c = Desktop(False, 0, 0)
    c.setInfo()
    c.calccostPerGB()
    
elif choice == 3:
    c = Supercomputer("country", 0, 0)
    c.setInfo()
    c.calcspacePerProcessor()
    
else:
    print("An invalid choice was selected.")
