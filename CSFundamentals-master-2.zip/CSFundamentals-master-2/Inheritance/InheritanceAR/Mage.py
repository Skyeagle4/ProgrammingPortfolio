#!/usr/bin/env python3
#Addison Richey created 3/2/17
import random
from Hero import Hero
class Mage(Hero):
    def __init__(self):
        Hero.__init__(self)
        self.sSlots = 0
        self.sd = 4
        self.sdd = 6
        self.ttstats = [0,0,0,0,0,0]
        self.ddie = 4
        
    def assignStats(self):
        x = 0
        self.ttstats = sorted(self.tstats)
        self.stats['Int'] = self.ttstats[5]
        dex =self.stats['Dex'] = self.ttstats[4]
        self.hp = self.stats['Con'] = self.ttstats[3]
        self.stats['Wis'] = self.ttstats[2]
        self.stats['Cha'] = self.ttstats[1]
        self.stats['Str'] = self.ttstats[0]
        self.ac = 10 + (int((dex-11)/2))
        self.abonus = (int((dex-11)/2))
        self.sSlots = (int((self.stats['Int']-10)/2))+1
        
    def spellCast(self):
        if self.sSlots>0:
            a = (int((self.stats['Int']-11)/2))+2
            a += random.randint(1,20)
            print 'you hit ac ', a, ' for ', self.sDam(), 'damage'
            self.sSlots -=1
        else:
            print 'out of spell slots'
    def sDam(self):
        d = 0
        for i in range(0,self.sd):
            d+= random.randint(1,self.sdd)
        return d
