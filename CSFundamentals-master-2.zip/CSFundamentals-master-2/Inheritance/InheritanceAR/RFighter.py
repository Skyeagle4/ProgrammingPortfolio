#!/usr/bin/env python3
#Addison Richey created 3/2/17
import random
import time
from Hero import Hero
class RFighter(Hero):
    def __init__(self):
        Hero.__init__(self)
        self.ttstats = [0,0,0,0,0,0]
        self.ddie = 8
        self.sShots = 0
        self.r = 30
        
    def assignStats(self):
        x = 0
        self.ttstats = sorted(self.tstats)
        self.stats['Int'] = self.ttstats[0]
        dex =self.stats['Dex'] = self.ttstats[5]
        self.hp = self.stats['Con'] = self.ttstats[3]
        wis = self.stats['Wis'] = self.ttstats[4]
        self.stats['Cha'] = self.ttstats[1]
        st = self.stats['Str'] = self.ttstats[2]
        self.ac = 10 + dex-12
        self.abonus = (int((dex-11)/2))
        self.sShots = (int((wis-11)/2))-1
    def sShot(self):
        if self.sShots>0:
            a = (int((self.stats['Dex']-11)/2))+2
            a += random.randint(1,20)
            print 'you hit ac ', a, ' for ', self.sDam(), 'damage'
            sShots -= 1
        else:
            print 'out of super shots'
    def sDam(self):
        d = random.randint(1,10)+int((self.stats['Wis']+self.stats['Dex'])/5)
        return d