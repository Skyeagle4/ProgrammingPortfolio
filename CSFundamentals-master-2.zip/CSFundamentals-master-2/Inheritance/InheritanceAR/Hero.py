#!/usr/bin/env python3
#Addison Richey created 3/2/17
import random
class Hero:
    def __init__(self):
        self.stats = {'Str' : 10, 'Dex' : 10, 'Con' : 10, 'Int' : 10, 'Wis' : 10, 'Cha' : 10}
        self.hp = 0
        self.tstats= [0,0,0,0,0,0]
        self.ddie = 0
        self.r = 0
        self.ac = 10
        self.abonus = 0
    def rollStats(self):
        for i in range(-1,5):
            drolls = [random.randint(1,6),random.randint(1,6),random.randint(1,6),random.randint(1,6)]
            s = 0
            for x in range(-1,3):
                if (drolls[x] <= drolls[0] and drolls[x] <= drolls[1] and drolls[x] <= drolls[2] and drolls[x] <= drolls[3]):
                    drolls[x] = 0
                s += drolls[x]
                
            self.tstats[i] = s
    def attack(self):
        d = random.randint(1,self.ddie)+ self.abonus
        a = random.randint(1,20)+ self.abonus + 2
        print "you hit an AC of ", a, " within range ", self.r, " for ", d, " damage."
    def hpChange(self):
        c = input("how much has your hp changed? ")
        self.hp += c
    def getStats(self):
        print "\nHit Points: ", self.hp, "\nAC: ", self.ac, "\nStrength: ", self.stats['Str'], "\nDexterity: ", self.stats['Dex'], "\nConstitution: ", self.stats['Con'], "\nIntelligence: ", self.stats['Int'], "\nWisdom: ", self.stats['Wis'], "\nCharisma: ", self.stats['Cha']
        