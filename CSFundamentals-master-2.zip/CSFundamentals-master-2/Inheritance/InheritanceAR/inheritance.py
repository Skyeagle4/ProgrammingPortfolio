#!/usr/bin/env python3
#Addison Richey created 3/2/17
from Hero import Hero
from Mage import Mage
from Fighter import Fighter
from RFighter import RFighter
x = input("""what type of hero do you want?
          1. Mage
          2. Melee Fighter
          3. Ranged Fighter
          """)
if x==1:
    h = Mage()
    h.rollStats()
    h.assignStats()
    h.getStats()
    y = 1
    while y !=5:
        y = input("""What action would you like to do?
                  1. Attack
                  2. Change hp
                  3. Get stats
                  4. Cast a spell
                  5. quit
                  """)
        if y == 1:
            h.attack()
        if y == 2:
            h.hpChange()
        if y == 3:
            h.getStats()
        if y == 4:
            h.spellCast()
elif x==2:
    h = Fighter()
    h.rollStats()
    h.assignStats()
    h.getStats()
    y=0
    while y !=5:
        y = input("""What action would you like to do?
                  1. Attack
                  2. Change hp
                  3. Get stats
                  4. rage
                  5. quit
                  """)
        if y == 1:
            h.attack()
        if y == 2:
            h.hpChange()
        if y == 3:
            h.getStats()
        if y == 4:
            h.rage()
elif x==3:
    h = RFighter()
    h.rollStats()
    h.assignStats()
    h.getStats()
    y=0
    while y !=5:
        y = input("""What action would you like to do?
                  1. Attack
                  2. Change hp
                  3. Get stats
                  4. Super shot
                  5. quit
                  """)
        if y == 1:
            h.attack()
        if y == 2:
            h.hpChange()
        if y == 3:
            h.getStats()
        if y == 4:
            h.sShot()
else:
    print "Invalid answer. Goodbye."