#!/usr/bin/env python3
#Addison Richey created 3/2/17
import random
import time
from Hero import Hero
class Fighter(Hero):
    def __init__(self):
        Hero.__init__(self)
        self.ttstats = [0,0,0,0,0,0]
        self.ddie = 8
        self.rages = 0
        
    def assignStats(self):
        x = 0
        self.ttstats = sorted(self.tstats)
        self.stats['Int'] = self.ttstats[0]
        dex =self.stats['Dex'] = self.ttstats[3]
        self.hp = self.stats['Con'] = self.ttstats[4]
        self.stats['Wis'] = self.ttstats[2]
        self.stats['Cha'] = self.ttstats[1]
        st = self.stats['Str'] = self.ttstats[5]
        self.ac = 10 + (int((dex-11)/2))+4
        self.abonus = (int((st-11)/2))
        self.rages = 1
    def rage(self):
        t1 = time.time()
        if self.rages>0:
            self.abonus = (int((self.stats['Str']-11)/2))+self.rBonus()
            self.rages -= 1
        else:
            print "out of rages"
    def rBonus(self):
        st = self.stats['Str']
        if st>=18:
            b=3
        elif st>14:
            b=2
        else:
            b=1
        return b
        