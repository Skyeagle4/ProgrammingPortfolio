#James Ninow

class snowmobile: 
    parenttracklength = 0
    parenttredwidth = 0
    def __init__(self):
        print "Prints parent constructor"

    def snowmobileMethod(self):
        print 'Prints parent method'

    def setlength(self, length):
        track.parentlength = length

    def setwidth(self, width):
        tred.parentwidth = width

    def gettrack(self):
        print "Prints area:", length.parentlength * width.parentwidth

class track(): # define child class def __init__(self):
    print "Prints child constructor"

def childMethod(self):
    print 'Prints child method'