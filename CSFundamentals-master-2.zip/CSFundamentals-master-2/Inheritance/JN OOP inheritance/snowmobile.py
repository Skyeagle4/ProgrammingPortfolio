#James Ninow

class snowmobile:
    def track(self,tracklength, tredwidth):
        self.tracklength= l
        self.tredwidth= w
        
    def model(self):
        print("Enter [1] to enter track length. Enter [2] to enter tred width ")
        choice = input("Enter choice: ")