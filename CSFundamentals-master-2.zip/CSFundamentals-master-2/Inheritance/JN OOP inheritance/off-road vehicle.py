#james ninow

class RecVehicle:
    
    def __int__(self,tracklength, tredwidth, model, power, Make):
        self.tracklength= l
        self.tredwidth=w
        self.model= m
        self.power= p
        self.make= M
        
    def weight(self):
        print "tracklength in (in.):", l
        
    def power(self):
        print "tred width in (in.):", w     
      
    def model(self):
        print "model:", m
        
    def size(self):
        print "power (hp):", p
        
    def make(self):
        print "make:", M
    
 #s= snowmobile()
 #s.tracklength()
 #s.set
 
        
    
    

    

    
