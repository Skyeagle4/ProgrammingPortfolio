// Chanel van Ginkel
// 03.02.16
// Inheritance Assignment
//

#include <iostream>

using namespace std;

// Super Class
class Pay {
    public:
        void setHours(int h) {
            hours = h;
        }
        void setPay(float p) {
            pay = p;
        }
    protected:
        int hours;
        float pay;
};

// Sub class for managers
class Manager: public Pay {
    public:
        int getMwage() {
            return (hours * pay);
        }
};

// Sub class for hostesses
class Hostess: public Pay {
    public:
        int getHwage() {
            return (hours * pay);
        }
};

// Sub class for servers
class Server: public Pay {
    public:
        int getSwage() {
            return (hours * pay);
        }
   
};
//Boolean to loop code
bool runCode = true;

int main(void) {
    
    // Data types for user input
    int val = 0;
    char x = 'x';
    
    // Looping
    while(runCode == true){
        
        // User chooses Manger, hostess, or server
        cout << "CALCULATING WAGES: \n For MANAGER enter 'M' \n For HOSTESS enter 'H' \n For SERVER enter 'S' \n : ";
        cin >> x;
        
        // IF statement for choice ^^
        if ((x == 'M') || (x == 'm')) {
            
            //Code for Manager Wage
            Manager man;
            man.setPay(23.41);
    
            cout << "Hours your MANAGER has worked : ";
            cin >> val;
            man.setHours(val);
            cout << "Calculated wage : $" << man.getMwage() << endl;
            
            // Loops back to choices
            cout << "\n Would you like to calculate for another employee? \n For YES enter 'Y' \n For NO enter 'N' \n : ";
            cin >> x;
            if((x == 'y') || (x == 'Y')){
                runCode = true;
            }else if ((x == 'N') || (x == 'n')){
                runCode = false;
            // Ends loop
            }else {
                cout << "Input value not valid..." << endl;
                runCode = false;
            }
        
        
        } else if ((x == 'H') || (x == 'h')) {
            //Code for Hostess wage
            Hostess hos;
            hos.setPay(9.50);
            
            cout << "Hours your HOSTESS has worked : ";
            cin >> val;
            hos.setHours(val);
            cout << "Calculated wage : $" << hos.getHwage() << endl;
            
            // Loops back to choices
            cout << "\n Would you like to calculate for another employee? \n For YES enter 'Y' \n For NO enter 'N' \n : ";
            cin >> x;
            if((x == 'y') || (x == 'Y')){
                runCode = true;
            }else if ((x == 'N') || (x == 'n')){
                runCode = false;
            // Ends loop
            }else {
                cout << "Input value not valid..." << endl;
                runCode = false;
            }
        } else if ((x == 'S') || (x == 's')) {
            // Code for server wage
            Server ser;
            ser.setPay(7.50);
            
            cout << "Hours you SERVER has worker : ";
            cin >> val;
            ser.setHours(val);
            cout << "Calculated wage : $" << ser.getSwage() << endl;
            
            //Loops back to choice
            cout << "\n Would you like to calculate for another employee? \n For YES enter 'Y' \n For NO enter'N' \n : ";
            cin >> x;
            if((x == 'y') || (x == 'Y')){
                runCode = true;
            }else if ((x == 'n') || (x == 'N')){
                runCode = false;
            // Ends loop
            }else {
                cout << "Input value not valid..." << endl;
                runCode = false;
            }
        // Ends loop
        } else {
            cout << "Input value not valid..." << endl;
                runCode = false;
        }
        
    }
    

    return 0;
    
}
