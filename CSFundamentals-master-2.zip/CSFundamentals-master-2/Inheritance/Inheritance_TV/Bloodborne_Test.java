// Tessa Vu 3.6.2017
package Bloodborne;
public class Bloodborne_Test {
  public static void main(String[] args) {
    Cruel_Fate = new ();
    Lone_Survivor = new ();
    Military_Veteran = new ();
    Milquetoast = new ();
    Noble_Scion = new ();
    Professional = new ();
    Troubled_Childhood = new ();
    Violent_Past = new ();
    Waste_of_Skin = new ();
    Cruel_Fate.description();
    Lone_Survivor.description();
    Military_Veteran.description();
    Milquetoast.description();
    Noble_Scion.description();
    Professional.description();
    Troubled_Childhood.description();
    Violent_Past.description();
    Waste_of_Skin.description();
  }  
}
