// Tessa Vu 3.6.2017
package bloodborne;
public interface Bloodborne {
	public static final int level10 = 10;
	public static final int level4 = 4;
	void description();
	double origin(double bloodEchoes, double level);
}
