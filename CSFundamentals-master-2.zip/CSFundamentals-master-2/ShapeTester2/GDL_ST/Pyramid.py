#MODDED BY GREYLARSON
class Pyramid :

    def __init__(self, n, l, h) :
        self.n = n
        self.l = l
        self.h = h
    
    def getVolume(self) :
        if self.n == 3 : 
            print("\nVolume =", (self.h*self.l*self.l*(3**.5))/12)
        elif self.n == 4 :
            print("\nVolume =", self.l*self.l*self.h/3)
        else :
            print("\nNot an available pyramid type--try a square or triangular base\n")         
    def getSurfaceArea(self) :
        if self.n == 3 :
            print("Surface area =", self.l*self.l*(3**.5)/4 + 1.5*self.l*((self.l*(3**.5)/6)**2+self.h**2)**.5, "\n")
        elif self.n == 4 :
            print("Surface area =",self.l*self.l + 2*self.l*((self.l/2)**2+(self.h**2))**.5, "\n")
        else :
            print("\nNot an available pyramid type--try a square or triangular base\n")
