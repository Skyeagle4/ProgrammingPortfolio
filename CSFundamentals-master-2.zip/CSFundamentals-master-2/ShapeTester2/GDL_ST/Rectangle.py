#MODDED BY GREYLARSON
class Rectangle :

    def __init__(self, w, l, h) :
        self.w = w
        self.l = l
        self.h = h
    
    def getVolume(self) :
        print("\nVolume =", self.h*self.w*self.l)
    
    def getSurfaceArea(self) :

        self.sa = ((self.l*self.h)*2)+((self.w*self.h)*2)+((self.l*self.w)*2)
        print("Surface area =", self.sa, "\n")
