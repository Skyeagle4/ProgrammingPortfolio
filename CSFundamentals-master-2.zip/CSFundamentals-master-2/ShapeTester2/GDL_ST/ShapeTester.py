#ShapeTester
#Written by Dylan Webb on 2.10.17
#MODDED BY GREYLARSON

from Box import Box
from Pyramid import Pyramid
from Sphere import Sphere
from Rectangle import Rectangle

shapeNum = int(input("\nWhich polyhedron would you like to test?\n\nBox = 1\n\
Pyramid = 2\nSphere = 3\nRectangle = 4\n\nEnter polyhedron number: "))

#box
if shapeNum == 1 :
    
    boxW = float(input("\nEnter width: "))
    boxL = float(input("Enter length: "))
    boxH = float(input("Enter height: "))
    box1 = Box(boxW,boxL,boxH)
    box1.getVolume()
    box1.getSurfaceArea()
    
#pyramid
elif shapeNum == 2 :
    pyrN = float(input("\nEnter number of sides of base: "))
    pyrL = float(input("Enter side length of base: "))
    pyrH = float(input("Enter height: "))
    pyr1 = Pyramid(pyrN,pyrL,pyrH)
    pyr1.getVolume()
    pyr1.getSurfaceArea()
    
#sphere
elif shapeNum == 3 :
    r = float(input("\nEnter radius: "))
    s1 = Sphere(r)
    s1.getVolume()
    s1.getSurfaceArea()
#rectangle
if shapeNum == 4 :
    
    rectW = float(input("\nEnter width: "))
    rectL = float(input("Enter length: "))
    rectH = float(input("Enter height: "))
    rect1 = Rectangle(rectW,rectL,rectH)
    rect1.getVolume()
    rect1.getSurfaceArea()
    
else :
    print("\nNot a valid entry\n")
