class Pyramid:
 def __init__ (self,h, b):
      self.b = b
      self.h= h

def calcV(self):
    self.v = (1/3)*b*h
    return V
    
