class Sphere:
    V=0
    def __init__(self,r):
        self.r=r
        def calcV(self):
            V = (4/3)*3.14*(r^3)
            return V
