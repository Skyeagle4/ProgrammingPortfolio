#Edits made by Sarah Wallgren 2/24/17

from Box import Box
from Pyramid import Pyramid
from Sphere import Sphere
from Cylinder import Cylinder
run = True
 
while run:
    print("For box surface area and volume, enter [1]. \nFor pyramid surface area and volume, enter [2]. \nFor sphere surface area and volume, enter [3]. \nFor cylinder surface area and volume, enter [4]")
    choice = input("Enter choice: ")
    
    if choice == 1:
        b1 = (input(" Enter length: "),input("Enter width: "),input("Enter height: "))
        print ("The volume of your box is:" + V)

    elif choice == 2:
        p1 = (input(" Enter length: "),input("Enter height: "))
        print ("The volume of your pyramid is:" + V)

    elif choice ==3:
        s1 = (input(" Enter radius: "))
        print ("The volume of your sphere is:" + V)
    
    elif choice == 4:
        surfaceArea = (input("Enter radius: "), input("Enter height: "))
        print ("The surface area of your cylinder is: " + SA)
        print ("The volume of your cylinder is: " + V)
        
    else:
        print ("Your shape choice is invalid.")





 

