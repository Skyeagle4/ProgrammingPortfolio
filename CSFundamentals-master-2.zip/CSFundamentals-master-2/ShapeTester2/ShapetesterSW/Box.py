class Box:
 def __init__ (self, a, b, c):
      self.a = a
      self.b = b
      self.c = c

 def calcV(self):
    V = a*b*c
    return V


