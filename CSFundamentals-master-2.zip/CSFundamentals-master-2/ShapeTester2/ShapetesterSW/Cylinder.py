#Class created by Sarah Wallgren 2/24/17

class Cylinder:
    def __init__ (self, r, h):
        self.r = r
        self.h = h
    
    def calcV (self):
        V = (3.14* r** 2* h)
        return V
    
    def calcSA (self):
        SA = ((2* 3.14* r* h) + (2* 3.14* r** 2))
        return SA
        