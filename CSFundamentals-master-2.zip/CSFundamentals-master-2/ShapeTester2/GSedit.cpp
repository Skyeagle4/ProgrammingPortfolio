//Nick Duval

#include <iostream>
#include <cmath>
#include <math.h>

using namespace std;

class sphere {
   public:
      double r;
      double x;
      double volume(double r){
      double result = (4/3) * M_PI * r * r * r;
      return result;
      }
      double surface(double r){
      double result = 4 * M_PI * r * r;
      return result;
      }
      void setRadius(double r){
      x = r;   
      }
      private:
};

int main( ) {
    
   sphere s1;
   s1.r;
   double volume = 0.0;
   double surfaceArea = 0.0;
   
   cout << "what is the radius of the sphere?" << endl;
   cin >> s1.r;
   
   cout << "Volume of sphere: " << s1.surface(s1.r) << endl;
   
   cout << "surface area of sphere: " << s1.volume(s1.r)<< endl;
	
   return 0;
}