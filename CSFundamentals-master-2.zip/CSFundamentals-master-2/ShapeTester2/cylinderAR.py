#Katya Pogodaeva
class Cylinder:
    def __init__(self, r, h):
        self.r = r
        self.h = h
        self.v = 0
        self.sa = 0
    def getVolume(self):
        self.v = (self.r^2)*self.h*3.14
    def getSurfaceArea(self):
        self.sa = 2*(3.14(self.r*self.h))+2*(3.14(self.r^2))