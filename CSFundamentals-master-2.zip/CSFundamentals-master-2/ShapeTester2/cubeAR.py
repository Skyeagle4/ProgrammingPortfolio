#Katya Pogodaeva
class Cube:
    def __init__(self, a):
        self.a = a
        self.v = 0
        self.sa = 0
    def getVolume(self):
        self.v = (self.a)^3
    def getSurfaceArea(self):
        self.sa = (self.a^2)*6
