// nastassja motro 02/22/17

public class cylCalc {
    private double radius;
    private double height;
    public cylCalc(double r, double h) {
        radius = r;
        height = h;
    }
    public double getSurfaceArea() {
        double surfaceArea = 2 * Math.PI * radius *(height + radius);
        return surfaceArea;
    }
    
    public double getVolume() {
        double volume = Math.PI * radius * radius * height;
        return volume;
    }
}