// nastassja motro - changed on 02/22/17

import java.lang.Math;
public class sphereCalc {
	private double radius; // changed
	public sphereCalc(double r) {
		radius = r;
	}
	public double getSurfaceArea() {
		double surfaceArea = 4 * Math.PI * Math.pow(radius, 2); // changed
		return surfaceArea;
	}
	public double getVolume() {
		double volume = (4 / 3) * Math.PI * Math.pow(radius, 3); // changed
		return volume;
	}
}