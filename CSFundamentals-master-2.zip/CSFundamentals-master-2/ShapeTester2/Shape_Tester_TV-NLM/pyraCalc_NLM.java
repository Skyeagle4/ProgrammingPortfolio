// nastassja motro  - changed 02/22/17

import java.lang.Math;
public class pyraCalc {
	private double height; // changed
	//private double length;
	//private double width;
	private double baseLength; // changed
	public pyraCalc(double h, /*double l, double w*/ double b) {
		height = h;
		//length = l;
		//width = w;
		baseLength = b; // changed
	}
	public double getSurfaceArea() {
		double sideLength = Math.sqrt(height*height + baseLength*baseLength / 4); // changed
		double surfaceArea = 2 * sideLength * baseLength; // changed
		return surfaceArea; 
	}
	public double getVolume() {
		double volume = height * baseLength * baseLength / 3; // changed
		return volume;
	}
}