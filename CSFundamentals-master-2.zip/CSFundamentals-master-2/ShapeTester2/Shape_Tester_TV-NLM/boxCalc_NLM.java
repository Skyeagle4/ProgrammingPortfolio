// nastassja motro - changed on 02/22/17

public class boxCalc {
	private double height; // changed
	private double length; // changed
	private double width; // changed
	public boxCalc(double h, double l, double w) {
		height = h;
		length = l;
		width = w;
	}
	public double getSurfaceArea() {
		double surfaceArea = 2 * ((length*height)+(width*height)); // changed
		return surfaceArea;
	}
	public double getVolume() {
		double volume = height * length * width; // changed
		return volume;
	}
}