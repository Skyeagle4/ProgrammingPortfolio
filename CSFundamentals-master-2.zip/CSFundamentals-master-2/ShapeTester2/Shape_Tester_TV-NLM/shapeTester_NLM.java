// nastassja motro - changed things on 02/22/17

import java.util.Scanner;
public class shapeTester {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		double boxW, boxL, boxH, pyraH, pyraB, sphereR, cylH, cylR; // changed
		System.out.println("Radius of sphere: "); 
		sphereR = in.nextDouble(); // changed
		System.out.println("Height of box: ");
		boxH = in.nextDouble(); // changed
		System.out.println("Length of box: ");
		boxL = in.nextDouble(); // changed
		System.out.println("Width of box: ");
		boxW = in.nextDouble(); // changed
		System.out.println("Height of pyramid: ");
		pyraH = in.nextDouble(); // changed
		System.out.println("Base length of pyramid: ");
		pyraB = in.nextDouble(); // changed
		System.out.println("Height of cylinder: "); // changed
		cylH = in.nextDouble(); // changed
		System.out.println("Radius of cylinder: "); // changed
		cylR = in.nextDouble(); // changed
		boxCalc box = new boxCalc(boxH, boxL, boxW); // changed
		sphereCalc sphere = new sphereCalc(sphereR); // changed
		pyraCalc pyra = new pyraCalc(pyraH, pyraB); // changed
		cylCalc cyl = new cylCalc(cylR, cylH); // changed
		System.out.println("Box Volume: " + box.getVolume()); // changed
		System.out.println("Box Surface Area: " + box.getSurfaceArea()); // changed
		System.out.println("Sphere Volume: " + sphere.getVolume()); // changed
		System.out.println("Sphere Surface Area: " + sphere.getSurfaceArea()); // changed
		System.out.println("Pyramid Volume: " + pyra.getVolume()); // changed
		System.out.println("Pyramid Surface Area: " + pyra.getSurfaceArea()); // changed
		System.out.println("Cylinder Volume: " + cyl.getVolume()); // changed
		System.out.println("Cylinder Surface Area " + cyl.getSurfaceArea()); // changed
	}
}