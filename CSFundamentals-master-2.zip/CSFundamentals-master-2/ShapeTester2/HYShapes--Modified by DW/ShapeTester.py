from Box import Box
from Sphere import Sphere
from Pyramid import Pyramid
from Cylinder import Cylinder

print("Welcome to ShapeTester! \nThis is designed to find the Surface Area and Volume of a few shapes.")
print("Enter [1] to enter box mode. \nEnter [2] to enter sphere mode. \nEnter [3] to enter pyramid mode. \nEnter [4] to enter cylinder mode.")
choice = int(input("Enter choice: "))

if choice == 1:
    print("Box mode has been selected.")
    box1=Box(input("Enter length: "),input("Enter width: "),input("Enter height: "))
    box1.calcVol(box1.boxL,box1.boxW,box1.boxH)
    box1.calcSA(box1.boxL,box1.boxW,box1.boxH)
    
elif choice == 2:
    print("Sphere mode has been selected.")
    sphere1=Sphere(input("Enter radius: "))
    sphere1.calcVol(sphere1.sphereR)
    sphere1.calcSA(sphere1.sphereR)

elif choice == 3:
    print("Pyramid mode has been selected.")
    pyramid1=Pyramid(input("Enter length: "),input("Enter width: "),input("Enter height: "))
    pyramid1.calcVol(pyramid1.pyramidL,pyramid1.pyramidW,pyramid1.pyramidH)
    pyramid1.calcSA(pyramid1.pyramidL,pyramid1.pyramidW,pyramid1.pyramidH)

elif choice == 4:
    print("Cylinder mode has been selected.")
    cylinder1=Cylinder(input("Enter radius: "),input("Enter height: "))
    cylinder1.calcVol(cylinder1.r,cylinder1.h)
    cylinder1.calcSA(cylinder1.r,cylinder1.h)
    
else:
    print("An invalid choice was entered.")

#I changed the input for the shapes to floats rather than ints so that the
#output can be decimal expansions for surface area and so users can enter floats

#I also added cylinder mode! You may notice I used simpler variable names for
#the new class--it seemed simpler and they won't get mixed up with the others
#if you were to modify the rest of the classes to match because they're class-
#specific variables.

#Anyways it's a great program!
