import math
class Cylinder:
    def __init__(self,r,h):
        self.r = float(r)
        self.h = float(h)

    def calcVol(self,r,h):
        print("The volume is: " + str((r**2)*math.pi*h))

    def calcSA(self,r,h):
        print("The surface area is: " + str((r**2)*math.pi*2 + h*2*r*math.pi))
