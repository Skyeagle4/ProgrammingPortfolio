class Box:
    def __init__(self,boxL,boxW,boxH):
        self.boxL = float(boxL)
        self.boxW = float(boxW)
        self.boxH = float(boxH)

    def calcVol(self,boxL,boxW,boxH):
        print("The volume is: ")
        print(str(boxL*boxW*boxH))

    def calcSA(self,boxL,boxW,boxH):
        print("The surface area is: " , str(2*(boxW*boxL+boxH*boxL+boxH*boxW)))
