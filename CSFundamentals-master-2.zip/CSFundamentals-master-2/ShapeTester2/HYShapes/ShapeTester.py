#Howard Ying, Period 3A, Completed 02-17-2017
#Edited by James Ninow
from Box import Box
from Sphere import Sphere
from Pyramid import Pyramid
from cone import Cone

print("Welcome to ShapeTester! \nThis is designed to find the Surface Area and Volume of a few shapes.")
print("Enter [1] to enter box mode. \nEnter [2] to enter sphere mode. \nEnter [3] to enter pyramid mode. \nEnter [4] to enter cone mode")
choice = input("Enter choice: ")

if choice == 1:
    print("Box mode has been selected.")
    box1=Box(input("Enter length: "),input("Enter width: "),input("Enter height: "))
    box1.calcVol(box1.boxL,box1.boxW,box1.boxH)
    box1.calcSA(box1.boxL,box1.boxW,box1.boxH)
    
elif choice == 2:
    print("Sphere mode has been selected.")
    sphere1=Sphere(input("Enter radius: "))
    sphere1.calcVol(sphere1.sphereR)
    sphere1.calcSA(sphere1.sphereR)

elif choice == 3:
    print("Pyramid mode has been selected.")
    pyramid1=Pyramid(input("Enter length: "),input("Enter width: "),input("Enter height: "))
    pyramid1.calcVol(pyramid1.pyramidL,pyramid1.pyramidW,pyramid1.pyramidH)
    pyramid1.calcSA(pyramid1.pyramidL,pyramid1.pyramidW,pyramid1.pyramidH)
    
elif choice == 4:
    print("Cone mode has been selected.")
    Cone1=Cone(input("Enter radius: "),input("Enter height: "))
    Cone1.calcVol(Cone1.coneR,Cone1.coneH)
    Cone1.calcSA(Cone1.coneH,Cone1.coneR)
    
else:
    print("An invalid choice was entered.")
