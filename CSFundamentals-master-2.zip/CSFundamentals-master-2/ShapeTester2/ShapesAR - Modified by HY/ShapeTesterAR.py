#!/usr/bin/env python3
# Addison Richey 2/10/17
# Edited by Howard Ying 2/22/2017
#    Added "Cylinder" class
#    Added "Triangular Pyramid" class & modified entry point to allow for instantiation
#    Added "Cone" class
from boxAR import Box
from sphereAR import Sphere
from squarePyramidAR import Spyramid
from triangularPyramidAR import Tpyramid
from cylinderAR import Cylinder
from coneAR import Cone
t = input("What type of shape do you want to calculate volume and surface area for? \n1. Box \n2. Sphere \n3. Pyramid \n4. Cylinder \n5. Cone \n")
if (t==1):
    l = input("What is the length of the box? ")
    w = input("What is the width of the box? ")
    h = input("What is the height of the box? ")
    b1 = Box(l,w,h)
    b1.getVolume()
    b1.getSurfaceArea()
    print ("The volume of your box is: ", b1.v)
    print ("The surface area of your box is: ", b1.sa)
elif (t==2):
    r = input("What is the radius of the sphere? ")
    s1 = Sphere(r)
    s1.getVolume()
    s1.getSurfaceArea()
    print ("The volume of your sphere is: ", s1.v)
    print ("The surface area of your sphere is: ", s1.sa)
elif (t==3):
    a = input("What type of pyramid? \n1. Square \n2. Triangular \n")
    if (a == 1):
        l = input("What is the length of the base of the pyramid? ")
        w = input("What is the width of the base of the pyramid? ")
        h = input("What is the height of the pyramid? ")
        sp1 = Spyramid(l,w,h)
        sp1.getVolume()
        sp1.getSurfaceArea()
        print ("The volume of your pyramid is: ", sp1.v)
        print ("The surface area of your pyramid is: ", sp1.sa)
    elif (a == 2):
        b = input("What is the length of the base of the pyramid? ")
        h = input("What is the height of the base of the pyramid? ")
        s = input("What is the slant height of the pyramid? ")
        H = input("What is the height of the pyramid? ")
        tp1 = Tpyramid(b,h,s,H)
        tp1.getVolume()
        tp1.getSurfaceArea()
        print ("The volume of your pyramid is: ", tp1.v)
        print ("The surface area of your pyramid is: ", tp1.sa)
    else:
        print ("Sorry, invalid answer.")
elif (t==4):
    r = input("What is the radius of the base of the cylinder? ")
    h = input("What is the height of the cylinder? ")
    c1 = Cylinder(r, h)
    c1.getVolume()
    c1.getSurfaceArea()
    print ("The volume of your cylinder is: ", c1.v)
    print ("The surface area of your cylinder is: ", c1.sa)
elif (t==5):
    r = input("What is the radius of the base of the cone? ")
    h = input("What is the height of the cone? ")
    cn1 = Cone(r, h)
    cn1.getVolume()
    cn1.getSurfaceArea()
    print ("The volume of your cone is: ", cn1.v)
    print ("The surface area of your cone is: ", cn1.sa)
else:
    print ("Sorry, invalid answer.")
