#!/usr/bin/env python3
#Added by Howard Ying on 02/22/2017
import math
class Cylinder:
    def __init__(self, r, h):
        self.r = h
        self.h = h
        self.v = 0
        self.sa = 0
    
    def getVolume(self):
        self.v = math.pi*self.r**2*self.h
    def getSurfaceArea(self):
        self.sa = (2*math.pi*self.r*self.h) + (2*math.pi*self.r**2)