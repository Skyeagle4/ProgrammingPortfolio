#!/usr/bin/env python3
#Addison Richey 2/10/17
class Tpyramid:
    def __init__(self, b, h, s, H):
        self.b = b
        self.h = h
        self.s = s 
        self.H = H
        self.v = 0
        self.sa = 0
    def getVolume(self):
        self.v = (self.b*self.h*self.H)/6
 
    def getSurfaceArea(self):
        import math
        self.sa = ((self.h+self.b)/2)+((3*self.b*self.s)/2)