#!/usr/bin/env python3
#Addison Richey 2/10/17
class Cone:
    def __init__(self, r, h):
        self.r = r
        self.h = h
        self.v = 0
        self.sa = 0
    def getVolume(self):
        import math
        self.v = (math.pi*self.r**2*self.h)/3
    def getSurfaceArea(self):
        import math
        self.sa = math.pi*self.r*(self.r+math.sqrt(self.h**2+self.r**2))

