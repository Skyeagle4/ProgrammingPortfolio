import math

class Cylinder:

   def __init__(self, r, h):
      self.r = r
      self.h = h
   
   def getVolume(self):
      result = (self.r**2)*math.pi*self.h
      print "\nThe volume for your box:", result

   def displaySphere(self):
      print "Radius : ", self.r
      
   def getSurfaceArea(self):
      result = (2*math.pi*self.r*self.h)+(2*math.pi*(self.r**2))
      print "The surface area for your box:", result, "\n"