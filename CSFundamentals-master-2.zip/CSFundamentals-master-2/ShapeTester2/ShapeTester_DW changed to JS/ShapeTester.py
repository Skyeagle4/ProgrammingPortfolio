#ShapeTester
#Written by Dylan Webb on 2.10.17
#Modified by Jake Soulier 2.22.17

from Box import Box
from Pyramid import Pyramid
from Sphere import Sphere
from Cylinder import Cylinder
from RightRectangularPrism import Prism
from Cone import Cone

shapeNum = int(raw_input("\nWhich polyhedron would you like to test?\n\nBox = 1\n\
Pyramid = 2\nSphere = 3\nCylinder = 4\nRight Rectangular Prism = 5\nCone = 6\n\nEnter polyhedron number: "))

#box
if shapeNum == 1 :
    
    boxW = float(raw_input("\nEnter width: "))
    boxL = float(raw_input("Enter length: "))
    boxH = float(raw_input("Enter height: "))
    box1 = Box(boxW,boxL,boxH)
    box1.getVolume()
    box1.getSurfaceArea()
    
#pyramid
elif shapeNum == 2 :
    pyrN = float(raw_input("\nEnter number of sides of base: "))
    pyrL = float(raw_input("Enter side length of base: "))
    pyrH = float(raw_input("Enter height: "))
    pyr1 = Pyramid(pyrN,pyrL,pyrH)
    pyr1.getVolume()
    pyr1.getSurfaceArea()
    
#sphere
elif shapeNum == 3 :
    r = float(raw_input("\nEnter radius: "))
    s1 = Sphere(r)
    s1.getVolume()
    s1.getSurfaceArea()

#cylinder    
elif shapeNum == 4 :
    r = float(raw_input("\nEnter radius: "))
    h = float(raw_input("Enter height: "))
    c1 = Cylinder(r,h)
    c1.getVolume()
    c1.getSurfaceArea()

#prism    
elif shapeNum == 5 :
    priW = float(raw_input("\nEnter width: "))
    priL = float(raw_input("Enter length: "))
    priH = float(raw_input("Enter Height: "))
    pri1 = Prism(priW, priL, priH)
    pri1.getVolume()
    pri1.getSurfaceArea()

#cone    
elif shapeNum == 6 :
    conR = float(raw_input("\nEnter radius: "))
    conH = float(raw_input("Enter height: "))
    con1 = Cone(conR, conH)
    con1.getVolume()
    con1.getSurfaceArea()
    
else :
    print "Not a valid entry\n"