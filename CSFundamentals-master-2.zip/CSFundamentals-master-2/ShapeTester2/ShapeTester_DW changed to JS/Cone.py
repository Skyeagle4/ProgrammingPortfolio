import math

class Cone:

   def __init__(self, r, h):
      self.r = r
      self.h = h
   
   def getVolume(self):
      result = (self.r**2)*math.pi*(self.h/3)
      print "\nThe volume for your box:", result

   def displaySphere(self):
      print "Radius : ", self.r
      
   def getSurfaceArea(self):
      result = math.pi*self.r*(self.r+self.h+self.r)
      print "The surface area for your box:", result, "\n"