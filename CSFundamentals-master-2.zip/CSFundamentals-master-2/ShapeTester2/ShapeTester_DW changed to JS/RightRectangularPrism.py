class Prism :

    def __init__(self, w, l, h) :
        self.w = w
        self.l = l
        self.h = h
    
    def getVolume(self) :
        print "\nVolume =", self.h*self.w*self.l
    
    def getSurfaceArea(self) :
        print "Surface area =", 2*(self.w*self.l+self.h*self.l+self.h*self.w), "\n"