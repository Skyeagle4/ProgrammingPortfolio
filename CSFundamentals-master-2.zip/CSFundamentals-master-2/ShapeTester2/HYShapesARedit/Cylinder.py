#!/usr/bin/env python
# Addison Richey created 2/22/17
import math
class Cyl:

    def __init__(self, r, h):
        self.r = r
        self.h = h
        
    def calcVol(self):
        v = self.r**2*(math.pi)*self.h
        print "The volume is: ",v
    def calcSA(self):
        sa = 2*(math.pi)*self.r*self.h+2*math.pi*self.r**2
        print "The surface area is: ",sa
        