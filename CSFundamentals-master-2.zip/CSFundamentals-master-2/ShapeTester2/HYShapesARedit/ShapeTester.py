# Addison Richey edited 2/22/17, added Cylinder
from Box import Box
from Sphere import Sphere
from Pyramid import Pyramid
from Cylinder import Cyl
run = True
print("Welcome to ShapeTester! \nThis is designed to find the Surface Area and Volume of a few shapes.")
while run:
    
    print("Enter [1] to enter box mode. \nEnter [2] to enter sphere mode. \nEnter [3] to enter pyramid mode. \nEnter [4] to enter cylinder mode.")
    choice = input("Enter choice: ")

    if choice == 1:
        print("Box mode has been selected.")
        box1=Box(input("Enter length: "),input("Enter width: "),input("Enter height: "))
        box1.calcVol(box1.boxL,box1.boxW,box1.boxH)
        box1.calcSA(box1.boxL,box1.boxW,box1.boxH)
    
    elif choice == 2:
        print("Sphere mode has been selected.")
        sphere1=Sphere(input("Enter radius: "))
        sphere1.calcVol(sphere1.sphereR)
        sphere1.calcSA(sphere1.sphereR)

    elif choice == 3:
        print("Pyramid mode has been selected.")
        pyramid1=Pyramid(input("Enter length: "),input("Enter width: "),input("Enter height: "))
        pyramid1.calcVol(pyramid1.pyramidL,pyramid1.pyramidW,pyramid1.pyramidH)
        pyramid1.calcSA(pyramid1.pyramidL,pyramid1.pyramidW,pyramid1.pyramidH)
    
    elif choice == 4:
        print("Cylinder mode has been selected.")
        c1 = Cyl(input("Enter radius: "),input("Enter height: "))
        c1.calcVol()
        c1.calcSA()
   
    else:
        print("An invalid choice was entered.")
        
    if input("Would you like to continue? \nIf so press 1, otherwise press 0.\n") != 1:
        print "Goodbye"
        run = False
