//Tessa Vu
//The struggle was real.

import java.util.Scanner;
import java.util.Calendar;
public class BirthDate {
      public static void main(String[] args) {
            Scanner keyboard = new Scanner(System.in);
            System.out.println(“Year: “);
            int year = keyboard.nextInt();
            System.out.println(“Month: “);
            int month = keyboard.nextInt();
            System.out.println(“Day: ”);
            Calendar now = Calendar.getInstance();
public Age() {
                  this.millennium = millennium;
                  this.centuries = centuries;
                  this.decades = decades;
                  this.years = years;
                  this.months = months;
                  this.days = days;
                  this.hours = hours;
                  this.minutes = minutes;
                  this.seconds = seconds;
            }
            public int getMillennium() {
                  return this.millennium;
            }
            public int getCenturies() {
                  return this.centuries;
            }
            public int getDecades() {
                  return this.decades;
            }
            public int getYears() {
                  return this.years;
            }
            public int getMonths() {
                  return this.Months;
            }
            public int getDays() {
                  return this.days;
            }
            public int getHours() {
                  return this.hours;
            }
            public int getMinutes() {
                  return this.minutes;
            }
            public int getSeconds() {
                  return this.seconds;
            }
            }
      }
      System.out.println(millennium + “ millennia, “ + centuries + “ century, ” + decades + “ decade(s), ” + years + “ year(s), ” + months + “ month(s), ” + days + “ day(s), ” + hours + “ hour(s), ” + minutes + “ minute(s), ” + seconds + “ second(s).”);
}
