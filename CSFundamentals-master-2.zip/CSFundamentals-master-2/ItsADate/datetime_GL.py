

#grey larson\
import datetime;
now = datetime.datetime.now()
userInput = raw_input("enter birthday in YYYY/MM/DD format")
userInput2 = raw_input("enter other birthday in YYYY/MM/DD format")

if (len(userInput) == 10):
    userDay = userInput[8:10]
    userMonth = userInput[5:7]
    userYear = userInput[0:4]
   

    if (len(userInput2) == 10):    
        userDay2 = userInput2[8:10]
        userMonth2 = userInput2[5:7]
        userYear2 = userInput2[0:4]
        
        dage = int(userDay2) - int(userDay)
        mage = int(userMonth2) - int(userMonth)
        yage = int(userYear2) - int(userYear)
        timeDif = (yage *365 + mage * 30.4 + dage)
            
    endMIage = int(timeDif/365000)
    endCage = int(timeDif/36500)
    endDEage = int(timeDif/3650)
    endYage = int(timeDif/365)
    endY2age = (int(timeDif/365))
    endMage = int(((timeDif - endYage*365)-((timeDif - endYage *365)%30.4))/30.4)
    endDage = int((timeDif - endYage*365 - endMage*30.4))
    hours = int(24*endDage)
    minutes = int(hours*60)
    seconds = int(minutes*60)
    
    
    print "you are", endMIage, "milleniums, ",endCage, "centuries, ", endDEage, "decades, ", endY2age, "years," , endMage , "months, ", endDage , "days, ", hours ,"hours, " ,minutes ,"mintes, and ", seconds, "seconds old"
else:

    print ("incorrect, try again")
