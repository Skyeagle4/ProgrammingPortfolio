
# By Edward Prutski

import datetime;

now = datetime.datetime.now()
userInput1 = raw_input("Enter some date dd/mm/yyyy in this format: ")
userInput2 = raw_input("Enter a date to compare to in the future dd/mm/yyyy in this format: ")

if (len(userInput1) == 10):
    userDay1 = userInput1[0:2]
    userMonth1 = userInput1[3:5]
    userYear1 = userInput1[6:10]
    
    if (len(userInput2) == 10):
        
        
        userDay2 = userInput2[0:2]
        userMonth2 = userInput2[3:5]
        userYear2 = userInput2[6:10]
        
        dage = int(userDay2) - int(userDay1)
        mage = int(userMonth2) - int(userMonth1)
        yage = int(userYear2) - int(userYear1)
        
        timeDif = (yage * 365 + mage * 30.4 + dage)
        
        endMeage = int(timeDif/365000)
        endCage = int(timeDif/36500)
        endDeage = int(timeDif/3650)
        endYage = int(timeDif/365)
        endY2age = int((timeDif/365)-(endDeage*10))
        endMage = int((timeDif - endYage*365)-((timeDif - endYage*365)%30.4))/30.4
        endDage = int(timeDif - endYage*365 - endMage*30.4)
        hours = int(24*endDage)
        minutes = int(hours*60)
        seconds = int(minutes*60)
        print "You are ",endMeage ," millenniums  " , endCage , " Centuries " , endDeage , " Decades " , endY2age, " years " , endMage , " months and " , endDage , "days", hours ," hour(s) " , minutes , " minutes " , seconds ," seconds old "   
    else:
        print("Invalid input")
else:
    print("Invalid input")
