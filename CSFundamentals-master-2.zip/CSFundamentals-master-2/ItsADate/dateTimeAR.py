#!/usr/bin/env python3
#Addison Richey 2/3/17 
import time, datetime
now = time.gmtime(time.time()-25200)
nday = now.tm_mday
nyear = now.tm_year
nmon = now.tm_mon
bdate = input("enter you birthdate in YYYY/MM/DD format: ")
if (len(bdate) < 10 or len(bdate) > 10):
    print 'invalid input'
else:
    bday = int(bdate[8:])
    bmon = int(bdate[5:7])
    byear = int(bdate[:4])
    aday = nday - bday
    if (aday < 0):
        nmon = nmon - 1
        if (nmon == 9 or nmon == 4 or nmon == 6 or nmon == 11):
            aday = aday + 30
        elif (nmon == 2):
            aday = aday + 28
            
        else:
            aday = aday + 31
    amon = nmon - bmon
    if (amon < 0):
        nyear = nyear - 1
        amon = amon + 12
    ayear = nyear - byear
    if (ayear < 0):
        print "you haven't been born yet, please try again later"
    else:
        print ("You are " + str(ayear) + " years, " + str(amon) + " months, and " + str(aday) + " days old.")
    
