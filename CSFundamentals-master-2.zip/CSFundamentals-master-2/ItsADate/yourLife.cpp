/* Keegan Hardy • Mr. Kapptie (3A) • You're life Calculator*/

#include <iostream>
#include <ctime>

using namespace std;

int main() {
    int d;
    int m;
    int y;
    
    cout << "What year were you born in? (YYYY)" << endl;
    cin >> y;
    cout << "What month were you born in? (MM)" << endl;
    cin >> m;
    cout << "What day were you born on? (DD)" << endl;
    cin >> d;
    
    time_t now = time(0);
    
    tm * ltm = localtime(&now);
    
    unsigned long int l = (d * 86400) + (m * 2628000) + (y * 31536000);
    unsigned long int i = (1900 + ltm->tm_year) * 31536000;
    unsigned long int sec = (ltm->tm_mday * 86400) + ((1 + ltm->tm_mon) * 2628000) + (i);
    unsigned long int s = sec - l;
    long int min = s / 60;
    float h = min / 60;
    float days = h / 24;
    float months = days / 30;
    float years = months / 12;
    float dec = years / 10;
    float cent = years / 100;
    float mil = years / 1000;
    
    cout <<"You are approximately " << s << " seconds old."<< endl;
    cout <<"You are approximately " << min << " minutes old."<< endl;
    cout <<"You are approximately " << h << " hours old."<< endl;
    cout <<"You are approximately " << days << " days old."<< endl;
    cout <<"You are approximately " << months << " months old."<< endl;
    cout <<"You are approximately " << years << " years old."<< endl;
    cout <<"You are approximately " << dec << " decades old."<< endl;
    cout <<"You are approximately " << cent << " centuries old."<< endl;
    cout <<"You are approximately " << mil << " millenniums old."<< endl;
    
    
}
