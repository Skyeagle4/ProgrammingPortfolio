// Nastassja Motro
// I had some help with this monstrosity from my brother
import java.util.Scanner;
import java.util.Calendar;
public class CalculateAge {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Year you were born: ");
		int year = keyboard.nextInt();
		System.out.println("Month you were born in: ");
		int month = keyboard.nextInt();
		System.out.println("Day you were born: ");
		Calendar now = Calendar.getInstance();
public Date() {
			this.millenniums = millenniums;
			this.centuries = centuries;
			this.decades = decades;
			this.years = years;
			this.months = months;
			this.days = days;
			this.hours = hours;
			this.minutes = minutes;
			this.seconds = seconds;
		}
		public int getMillennium() {
			return this.millenniums;
		}
		public int getCenturies() {
			return this.centuries;
		}
		public int getDecades() {
			return this.decades;
		}
		public int getYears() {
			return this.years;
		}
		public int getMonths() {
			return this.Months;
		}
		public int getDays() {
			return this.days;
		}
		public int getHours() {
			return this.hours;
		}
		public int getMinutes() {
			return this.minutes;
		}
		public int getSeconds() {
			return this.seconds;
		}
		}
	}
	System.out.println("You are " + millenniums + " millennia, " + centuries + " century, " + decades + " decade(s), " + years + " year(s), " + months + " month(s), " + days + " day(s), " + hours + " hour(s), " + minutes + " minute(s), " + seconds + " second(s) old.");
}   
