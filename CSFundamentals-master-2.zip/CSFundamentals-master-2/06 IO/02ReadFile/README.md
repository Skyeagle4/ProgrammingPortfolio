Reading a file.
