Keegan Hardy
Nick Duval
Nirvik Sharma
Chanel van Ginkel
George Söderström
Brooks Boyack

This checkers game will be composed of two players. Two players will face off against eachother to play a game of checkers by pressing on board pieces that will illuminate with their color until they select a piece, which will change the color of the selected piece, as well as illuminating the available moves for the selected piece.
