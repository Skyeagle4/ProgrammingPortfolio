This is the folder to share all code accross platforms.
