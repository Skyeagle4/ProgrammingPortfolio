Keegan Hearty
George Soderstrom
Nick Duval
Nirvik Sharma
Chanel Van Ginkel
Brooks Boyack

The Trail game will be similar to the classic doss game Orgen trail.
this game will constist of many differne t serenrios wher player must mkae choices in a sererio, manage supplies, and keep their crew alive and make money.
Each group member will create a different class to repersent a sererio that the players may engage in to test
