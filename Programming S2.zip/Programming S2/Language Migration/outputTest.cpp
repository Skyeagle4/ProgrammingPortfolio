#include <iostream>

using namespace std;

int main() {
    int i = 1, j = 2, k = 3, r;
    
    r = (i, j, k);
    
    cout << r << endl;
}