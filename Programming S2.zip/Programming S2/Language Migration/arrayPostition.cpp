#include <iostream>
#include <array>
#include <cstdlib>

using namespace std;

int main() {
    int list [] = {1,2,3,4,5,6,7,8,9,10};
    for (int i = 0; i < 10; i++) {
        cout << list[i] << endl;
    }
    
    return 0;
}