#include <iostream>
#include <stdlib.h>
#include <ctime>

using namespace std;

int main() {
    
}