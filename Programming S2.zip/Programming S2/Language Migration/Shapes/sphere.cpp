#include <iostream>

class Sphere {
    public:
}

using namespace std;

int main() {
    
}