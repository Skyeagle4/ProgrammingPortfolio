#include <iostream>

using namespace std;

int main () {
    int num1 = 10;
    cout << "num 1 :" << num1 << endl;
    return 0;
}